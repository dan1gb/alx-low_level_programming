#include "main.h"
/**
 *_islower - function to print lowercase
 *Return: returns 1 if lowercase, else 1
 *@c: parameter to be printed
 */
int _islower(int c)
{
if (c > 96 && c <= 123)
{
	return (1);
}
else
{
return (0);
}
}
