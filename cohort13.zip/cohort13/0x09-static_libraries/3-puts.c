#include "main.h"
/**
 * _puts - function itselfu
 * @str: pointer as argument
 * Return: none
 */
void _puts(char *str)
{
}
