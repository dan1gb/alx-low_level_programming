Static and Dynamic Libraries
