#include "main.h"
/**
 * _abs - function to find absolute numbers
 * @num - argument accepted
 * Return: returns the number in absolute form
 * @num: argument accepted
*/
int _abs(int num)
{
if (num > 0)
{
	return (num);
}
if (num < 0)
{
	return (-num);
}
else
{
	return (num);
}
}
