#include<stdio.h>
/**
* main - program entry point
* @argc: argument counter
* @argv: argument vector
* Return: always 0
*/

int main(int argc, char *argv[])
{
printf("%s\n", argv[argc * 0]);
return (0);
}
