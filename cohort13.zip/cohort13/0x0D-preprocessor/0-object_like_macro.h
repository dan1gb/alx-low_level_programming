#ifndef OBJECT_LIKE_MACRO_H
#define OBJECT_LIKE_MACRO_H
/**
* File: 0-object_like_macro.h
* Description: Defines a macro named size of value 1024
*/

#define SIZE 1024
#endif
