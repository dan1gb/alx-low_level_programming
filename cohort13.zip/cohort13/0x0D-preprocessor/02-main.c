#include <stdio.h>

/**
  * main - entry point
  * Return: 0
  */

int main(void)
{
	printf("%s\n", __FILE__);
	return (0);
}
