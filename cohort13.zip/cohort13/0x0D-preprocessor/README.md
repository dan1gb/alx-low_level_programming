C-Preprocessor and macro things.
