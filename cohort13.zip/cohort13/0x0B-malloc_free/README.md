Dynamic memory allocation using Malloc
