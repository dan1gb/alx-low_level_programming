Now into Recursion. Feels like an echo in here
